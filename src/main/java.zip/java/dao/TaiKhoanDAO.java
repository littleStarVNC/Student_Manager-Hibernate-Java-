package dao;

import model.TaiKhoan;

public interface TaiKhoanDAO {
    TaiKhoan login(String tenDangNhap);
//    void saveTaiKhoan(TaiKhoan taiKhoan);
}
