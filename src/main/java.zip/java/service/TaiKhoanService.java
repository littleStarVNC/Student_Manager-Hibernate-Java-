package service;

import model.TaiKhoan;

public interface TaiKhoanService {
    
    public TaiKhoan login(String tenDangNhap, String matKhau);
    
}