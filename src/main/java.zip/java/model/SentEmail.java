package model;

public class SentEmail {
private int haa;

public int getHaa() {
	return haa;
}

public void setHaa(int haa) {
	this.haa = haa;
}
}
